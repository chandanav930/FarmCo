import React, { useEffect, useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import { Sprout, Menu, X, MapPin, ArrowRight, Leaf, CalendarDays, Users, CheckCircle2, Instagram, Mail, Phone, Search } from "lucide-react";
import "./style.css";

const farms = [
  { id: 1, name: "Green Valley Organic Farm", place: "Bengaluru outskirts", type: "Farm Day", price: 799, tag: "Popular", image: "https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1100&q=85", desc: "Walk through lush fields, meet the farmers and discover how fresh food is grown.", activities: "Farm walk · Harvesting · Organic lunch" },
  { id: 2, name: "The Mango Grove", place: "Ramanagara, Karnataka", type: "Harvest", price: 599, tag: "Seasonal", image: "https://images.unsplash.com/photo-1523348837708-15d4a09cfac2?auto=format&fit=crop&w=1100&q=85", desc: "Enjoy a hands-on countryside day among fruit trees and learn about orchard care.", activities: "Orchard tour · Fruit picking · Tasting" },
  { id: 3, name: "Earth & Earth Farmstay", place: "Chikkaballapur, Karnataka", type: "Farm Stay", price: 2499, tag: "Stay", image: "https://images.unsplash.com/photo-1470770841072-f978cf4d019e?auto=format&fit=crop&w=1100&q=85", desc: "Slow down with a peaceful rural stay, local food and simple farm experiences.", activities: "Farm stay · Local cuisine · Nature walk" },
  { id: 4, name: "Little Sprouts Learning Farm", place: "Devanahalli, Karnataka", type: "Workshop", price: 499, tag: "Families", image: "https://images.unsplash.com/photo-1492496913980-501348b61469?auto=format&fit=crop&w=1100&q=85", desc: "A joyful learning experience for children and adults to connect with the soil.", activities: "Seed planting · Composting · Garden play" }
];

function App() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState(null);
  const [booking, setBooking] = useState(null);
  const [farmerOpen, setFarmerOpen] = useState(false);
  const [notice, setNotice] = useState("");
  const [bookings, setBookings] = useState(() => JSON.parse(localStorage.getItem("farmco-bookings") || "[]"));
  const [farmers, setFarmers] = useState(() => JSON.parse(localStorage.getItem("farmco-farmers") || "[]"));

  useEffect(() => {
    if ("serviceWorker" in navigator) navigator.serviceWorker.register("/sw.js").catch(() => {});
  }, []);
  const filtered = useMemo(() => farms.filter(f => `${f.name} ${f.place} ${f.type}`.toLowerCase().includes(search.toLowerCase())), [search]);

  function submitBooking(e) {
    e.preventDefault();
    const data = Object.fromEntries(new FormData(e.currentTarget));
    const next = [...bookings, { ...data, farm: booking.name, created: new Date().toISOString() }];
    setBookings(next); localStorage.setItem("farmco-bookings", JSON.stringify(next));
    setBooking(null); setSelected(null); setNotice("Your booking request has been saved! The Farm Co. team will contact you to confirm.");
  }
  function submitFarmer(e) {
    e.preventDefault();
    const data = Object.fromEntries(new FormData(e.currentTarget));
    const next = [...farmers, { ...data, created: new Date().toISOString() }];
    setFarmers(next); localStorage.setItem("farmco-farmers", JSON.stringify(next));
    setFarmerOpen(false); setNotice("Thank you for registering your farm. Our team will get in touch.");
  }

  return <div>
    <header className="nav">
      <a className="brand" href="#home"><span className="brand-icon"><Sprout size={23}/></span><span>farm<span className="brand-light">co.</span><small>GROW • EXPLORE • CONNECT</small></span></a>
      <nav className={menuOpen ? "nav-links open" : "nav-links"}>
        <a href="#explore" onClick={()=>setMenuOpen(false)}>Explore farms</a><a href="#how" onClick={()=>setMenuOpen(false)}>How it works</a><a href="#about" onClick={()=>setMenuOpen(false)}>Our story</a>
        <button className="nav-cta" onClick={()=>{setFarmerOpen(true);setMenuOpen(false)}}>Partner with us <ArrowRight size={15}/></button>
      </nav>
      <button className="menu-btn" onClick={()=>setMenuOpen(!menuOpen)} aria-label="Toggle menu">{menuOpen?<X/>:<Menu/>}</button>
    </header>

    <main>
      <section className="hero" id="home">
        <div className="hero-shade"></div>
        <div className="hero-content">
          <div className="eyebrow"><span></span> A NEW WAY TO EXPERIENCE THE COUNTRYSIDE</div>
          <h1>Get closer to<br/><em>where life grows.</em></h1>
          <p>Trade screens for green fields. Meet real farmers, get your hands in the soil and discover the joy of farm life.</p>
          <div className="hero-actions"><a className="btn btn-primary" href="#explore">Explore experiences <ArrowRight size={17}/></a><a className="text-link light" href="#about">Discover our story <span>↗</span></a></div>
          <div className="hero-note"><div className="avatar-stack"><i>🌱</i><i>🌾</i><i>🌿</i></div><span>Real farms. Meaningful experiences.</span></div>
        </div>
        <div className="hero-caption">ROOTED IN NATURE. MADE FOR EVERYONE.</div>
      </section>

      <section className="intro section" id="about">
        <div className="intro-label"><span className="line"></span> MORE THAN A DAY OUT</div>
        <div className="intro-grid"><h2>Reconnect with nature.<br/><em>Experience farming.</em></h2><div><p className="intro-copy">Farm Co. brings people and farmers together through unforgettable countryside experiences. Discover the stories behind your food, learn new skills and support the people who grow it.</p><a className="text-link" href="#how">Why Farm Co. <span>↗</span></a></div></div>
        <div className="values"><div><Leaf/><b>Learn by doing</b><span>Get hands-on with real farm activities.</span></div><div><Users/><b>Support farmers</b><span>Create new opportunities for rural communities.</span></div><div><Sprout/><b>Grow sustainably</b><span>Build a deeper connection with the earth.</span></div></div>
      </section>

      <section className="explore section" id="explore">
        <div className="section-head"><div><div className="intro-label"><span className="line"></span> FIND YOUR EXPERIENCE</div><h2>Fresh air is <em>calling.</em></h2><p>Little adventures. Lasting memories. Find your kind of farm day.</p></div><div className="search-box"><Search size={17}/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search farms or experiences"/></div></div>
        <div className="farm-grid">{filtered.map(f=><article className="farm-card" key={f.id}><button className="image-button" onClick={()=>setSelected(f)}><img src={f.image} alt={f.name}/><span className="tag">{f.tag}</span><span className="image-arrow"><ArrowRight size={18}/></span></button><div className="farm-info"><div className="farm-place"><MapPin size={13}/>{f.place}</div><h3>{f.name}</h3><p>{f.activities}</p><div className="farm-bottom"><span>From <b>₹{f.price.toLocaleString("en-IN")}</b> <small>/ person</small></span><button onClick={()=>setSelected(f)}>View experience <ArrowRight size={15}/></button></div></div></article>)}</div>
        {filtered.length===0&&<p className="empty">No farms match that search yet. Try another name or location.</p>}
        <p className="demo-note">Sample experiences shown for the MVP. Farm listings, prices and availability must be verified before accepting live bookings.</p>
      </section>

      <section className="how section" id="how"><div className="how-top"><div className="intro-label"><span className="line"></span> SIMPLE AS IT SHOULD BE</div><h2>Your farm day,<br/><em>in three steps.</em></h2></div><div className="steps"><div><span>01</span><CalendarDays/><h3>Find your farm</h3><p>Explore unique farms and choose an experience that feels right.</p></div><div><span>02</span><Users/><h3>Send a request</h3><p>Choose your date and group size. The farm team can confirm details.</p></div><div><span>03</span><Sprout/><h3>Get out there</h3><p>Meet your hosts, learn something new and make memories outdoors.</p></div></div></section>

      <section className="partner"><div><div className="intro-label light-label"><span className="line"></span> GROW WITH FARM CO.</div><h2>Have a farm?<br/><em>Let's grow together.</em></h2><p>Share your farm with curious explorers and create new income opportunities for your community.</p><button className="btn btn-cream" onClick={()=>setFarmerOpen(true)}>Become a farm partner <ArrowRight size={17}/></button></div><div className="partner-art"><div className="circle c1"></div><div className="circle c2"></div><Sprout size={150} strokeWidth={0.8}/></div></section>
    </main>

    <footer><div className="footer-main"><a className="brand footer-brand" href="#home"><span className="brand-icon"><Sprout size={23}/></span><span>farm<span className="brand-light">co.</span><small>GROW • EXPLORE • CONNECT</small></span></a><p>Bringing people closer to the land<br/>and the people who care for it.</p><div className="footer-links"><a href="#explore">Explore</a><a href="#about">Our story</a><button onClick={()=>setFarmerOpen(true)}>Partner with us</button></div></div><div className="footer-bottom"><span>© {new Date().getFullYear()} Farm Co. All rights reserved.</span><span>Made for a greener tomorrow <Leaf size={14}/></span></div></footer>

    {notice&&<div className="toast"><CheckCircle2/>{notice}<button onClick={()=>setNotice("")}>×</button></div>}
    {selected&&<div className="modal-backdrop" onClick={()=>setSelected(null)}><div className="modal" onClick={e=>e.stopPropagation()}><button className="close" onClick={()=>setSelected(null)}><X/></button><img className="modal-image" src={selected.image} alt=""/><div className="modal-body"><div className="farm-place"><MapPin size={13}/>{selected.place}</div><h2>{selected.name}</h2><p>{selected.desc}</p><p className="modal-activities">{selected.activities}</p><div className="modal-price">From <b>₹{selected.price.toLocaleString("en-IN")}</b> / person</div><button className="btn btn-primary full" onClick={()=>setBooking(selected)}>Request a booking <ArrowRight size={16}/></button></div></div></div>}
    {booking&&<div className="modal-backdrop" onClick={()=>setBooking(null)}><div className="form-modal" onClick={e=>e.stopPropagation()}><button className="close" onClick={()=>setBooking(null)}><X/></button><div className="intro-label"><span className="line"></span> BOOK AN EXPERIENCE</div><h2>{booking.name}</h2><p>Send a request and the Farm Co. team can follow up to confirm availability.</p><form onSubmit={submitBooking}><label>Your name<input name="name" required placeholder="Full name"/></label><label>Email address<input name="email" type="email" required placeholder="you@example.com"/></label><label>Phone number<input name="phone" type="tel" required placeholder="+91"/></label><div className="form-row"><label>Preferred date<input name="date" type="date" required min={new Date().toISOString().slice(0,10)}/></label><label>Guests<input name="guests" type="number" min="1" max="30" defaultValue="2" required/></label></div><button className="btn btn-primary full" type="submit">Submit booking request <ArrowRight size={16}/></button></form></div></div>}
    {farmerOpen&&<div className="modal-backdrop" onClick={()=>setFarmerOpen(false)}><div className="form-modal" onClick={e=>e.stopPropagation()}><button className="close" onClick={()=>setFarmerOpen(false)}><X/></button><div className="intro-label"><span className="line"></span> FARM PARTNERSHIP</div><h2>Let's grow <em>together.</em></h2><p>Tell us a little about your farm. Our team can reach out to discuss a partnership.</p><form onSubmit={submitFarmer}><label>Farm / owner name<input name="owner" required placeholder="Your name or farm name"/></label><label>Location<input name="location" required placeholder="Village, district, state"/></label><label>Phone number<input name="phone" required type="tel" placeholder="+91"/></label><label>Email address<input name="email" required type="email" placeholder="you@example.com"/></label><label>What experiences can you offer?<textarea name="experiences" rows="3" placeholder="Farm visits, harvesting, workshops, farm stays..."/></label><button className="btn btn-primary full" type="submit">Send partnership enquiry <ArrowRight size={16}/></button></form></div></div>}
  </div>
}
createRoot(document.getElementById("root")).render(<App/>);