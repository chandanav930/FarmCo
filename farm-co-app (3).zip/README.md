# Farm Co. — Free MVP starter

A responsive Farm Co. website and installable PWA built with React + Vite.

## Run locally
1. Install Node.js LTS from https://nodejs.org/
2. Open this folder in VS Code.
3. Open Terminal → New Terminal.
4. Run:
   ```bash
   npm install
   npm run dev
   ```
5. Open the local URL printed in the terminal (usually http://localhost:5173).

## Create a production build
```bash
npm run build
npm run preview
```
The production website is generated in `dist/`.

## Free publishing
You can publish the `dist` output using GitHub Pages or a free static hosting tier such as Netlify or Vercel. For GitHub Pages, configure the repository's Pages deployment to build with `npm run build` and publish `dist` (or use a GitHub Actions workflow).

## What works in this MVP
- Responsive landing page and farm discovery/search
- Farm detail popups
- Booking request form
- Farmer partnership registration form
- PWA manifest and service worker

## Important MVP limitations
- Booking and farmer form submissions are stored only in that browser's local storage. They are not sent to you and are not shared across devices.
- Farm listings, images, prices and locations are sample content. Verify them and obtain permission before publishing.
- No live payment processing, customer accounts, admin dashboard, email/SMS notifications or shared database are connected yet. Those require backend services and configuration.
- The PWA can be installed from a supported browser; this is not yet a Play Store or Apple App Store native app.

## Next production step
Connect a backend such as Supabase (free tier subject to its current limits), add an owner/admin dashboard and configure a payment provider only after business and account verification.
